**FutureCrypt**

Version 1

Inspired by [this video](https://www.youtube.com/watch?v=oa2aL6Y8X_c)